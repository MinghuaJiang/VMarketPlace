package edu.virginia.cs.vmarketplace.service.login;

import android.net.Uri;

/**
 * Created by cutehuazai on 12/3/17.
 */

public class GoogleEnrichStrategy implements AppUserEnrichStrategy {
    @Override
    public String getUserName(){
        return null;
    }

    @Override
    public Uri getUserPicUri() {
        return null;
    }

}
